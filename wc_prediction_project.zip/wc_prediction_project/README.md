# FIFA World Cup 2026 Prediction Project

## Overview
End-to-end ML project for predicting WC outcomes using historical data.

## Setup
1. pip install -r requirements.txt
2. python train.py
3. streamlit run app.py

## Features
- Data processing from provided CSVs
- ML models for match prediction
- Monte Carlo tournament simulation
- Interactive Streamlit dashboard
- Focus on Egypt probabilities

## Structure
See project folders.

Built for portfolio/graduation project.
