import pandas as pd
import numpy as np
import os

def load_data(data_dir='data'):
    matches = pd.read_csv(os.path.join(data_dir, 'wc_all_matches.csv'))
    teams = pd.read_csv(os.path.join(data_dir, 'wc_2026_teams.csv'))
    editions = pd.read_csv(os.path.join(data_dir, 'wc_all_editions.csv'))
    return matches, teams, editions

print("Data loader ready.")
